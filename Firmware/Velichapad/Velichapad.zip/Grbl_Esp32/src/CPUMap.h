// Machine configuration is now done in machine.h
// Read that file for instructions.
